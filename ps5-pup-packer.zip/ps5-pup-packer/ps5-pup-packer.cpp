// ps5-pup-packer.cpp - Made by antichrist

#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
#include "PUP.h"
#include "Entry.h"
#include "BinaryReader.h"

int main(int argc, char* argv[]) {
    if (argc < 3) {
        std::cout << "Usage: " << argv[0] << " <decrypted_input.pup> <output.pup> [mods_folder]\n";
        return 1;
    }

    std::string inputPath = argv[1];
    std::string outputPath = argv[2];

    // Open the decrypted PUP using the repo's BinaryReader (file path)
    CBinaryReader reader(inputPath.c_str());

    std::cout << "PUP loaded successfully using BinaryReader.\n";

    // Simple copy for now (we can extend later once it builds)
    std::ifstream in(inputPath, std::ios::binary | std::ios::ate);
    if (!in) {
        std::cerr << "Failed to open input for copying.\n";
        return 1;
    }

    std::ofstream out(outputPath, std::ios::binary);
    if (out) {
        in.seekg(0);
        out << in.rdbuf();
        std::cout << "\nBasic PUP copy created: " << outputPath << std::endl;
    }

    std::cout << "\n=== PS5 PUP Packer Tool ===\n";
    std::cout << "The output is UNSIGNED and UNENCRYPTED.\n";
    std::cout << "WARNING: Can only be used on already jailbroken PS5 consoles.\n";
    std::cout << "Do not attempt to flash it on OFW.\n";

    return 0;
}
